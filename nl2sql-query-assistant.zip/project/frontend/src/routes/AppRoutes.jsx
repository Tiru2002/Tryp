import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Auth Components
import ProtectedRoute from '../components/auth/ProtectedRoute';
import AuthScreen from '../components/auth/AuthScreen';
import SetupPassword from '../components/auth/SetupPassword';

// Dashboard Containers
import QueryDashboard from '../components/query/QueryDashboard';
import AdminDashboard from '../components/admin/AdminDashboard';

function AppRoutes({ token, isAdmin, userProfile, setUserProfile, setToken, setIsAdmin, onLogout }) {
  return (
    <Routes>

      {/* PUBLIC ROUTE: Login / Request Setup Link */}
      <Route
        path="/login"
        element={
          token ? (
            <Navigate to="/query" replace />
          ) : (
            <AuthScreen
              setToken={setToken}
              setIsAdmin={setIsAdmin}
              setUserProfile={setUserProfile}
            />
          )
        }
      />

      <Route
        path="/setup-password"
        element={<SetupPassword />}
      />

      {/* PROTECTED ROUTE: Standard User Query Interface */}
      <Route
        path="/query"
        element={
          <ProtectedRoute isAllowed={!!token} redirectPath="/login">
            <QueryDashboard
              token={token}
              isAdmin={isAdmin}
              onLogout={onLogout}
              userProfile={userProfile}
            />
          </ProtectedRoute>
        }
      />

      {/* PROTECTED ROUTE: Administrative Management Suite */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute isAllowed={!!token && isAdmin} redirectPath="/query">
            <AdminDashboard
              token={token}
              onLogout={onLogout}
            />
          </ProtectedRoute>
        }
      />

      {/* CATCH-ALL ROUTE */}
      <Route
        path="*"
        element={<Navigate to={token ? "/query" : "/login"} replace />}
      />

    </Routes>
  );
}

export default AppRoutes;
