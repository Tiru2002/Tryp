import { createTheme } from '@mui/material/styles';

// ---------------------------------------------------------------------------
// BRAND PALETTE — only these three colors are used anywhere in the app.
// Every other value below is a tint, shade, or opacity of one of these three,
// used purely to create elevation/hierarchy (cards vs page vs hover states),
// never introducing a new hue.
// ---------------------------------------------------------------------------
const ACCENT_ORANGE = '#FF6B01';
const TEXT_LIGHT = '#FFFFFF';
const BG_DARKGREY = '#353535';

// Derived shades of BG_DARKGREY for layering (page background sits behind
// the #353535 cards/panels the brief specifies).
const BG_PAGE = '#232323';      // page background, darker than cards
const BG_ELEVATED = '#3F3F3F';  // hover / raised surface, lighter than cards
const BG_INPUT = '#2C2C2C';     // input fields, sits between page and card

// Derived shades/tints of the accent, for hover/active/disabled states only.
const ACCENT_HOVER = '#E05F00';
const ACCENT_MUTED = 'rgba(255, 107, 1, 0.16)';
const ACCENT_BORDER = 'rgba(255, 107, 1, 0.5)';

// Opacity ramps of white, for secondary text / dividers / disabled states.
const TEXT_SECONDARY = 'rgba(255, 255, 255, 0.70)';
const TEXT_DISABLED = 'rgba(255, 255, 255, 0.38)';
const DIVIDER = 'rgba(255, 255, 255, 0.12)';
const HAIRLINE = 'rgba(255, 255, 255, 0.08)';

export const brand = {
  orange: ACCENT_ORANGE,
  orangeHover: ACCENT_HOVER,
  orangeMuted: ACCENT_MUTED,
  orangeBorder: ACCENT_BORDER,
  white: TEXT_LIGHT,
  darkGrey: BG_DARKGREY,
  page: BG_PAGE,
  elevated: BG_ELEVATED,
  input: BG_INPUT,
  textSecondary: TEXT_SECONDARY,
  textDisabled: TEXT_DISABLED,
  divider: DIVIDER,
  hairline: HAIRLINE,
};

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: ACCENT_ORANGE,
      light: '#FF8A3D',
      dark: ACCENT_HOVER,
      contrastText: TEXT_LIGHT,
    },
    background: {
      default: BG_PAGE,
      paper: BG_DARKGREY,
    },
    text: {
      primary: TEXT_LIGHT,
      secondary: TEXT_SECONDARY,
      disabled: TEXT_DISABLED,
    },
    divider: DIVIDER,
    // Status colors are intentionally NOT new hues — they reuse orange/white
    // at different weights so the whole app stays inside the 3-color brief.
    success: { main: ACCENT_ORANGE, contrastText: TEXT_LIGHT },
    error: { main: TEXT_LIGHT, contrastText: BG_DARKGREY },
    warning: { main: ACCENT_ORANGE, contrastText: TEXT_LIGHT },
    info: { main: TEXT_LIGHT, contrastText: BG_DARKGREY },
  },
  shape: {
    borderRadius: 10,
  },
  typography: {
    fontFamily: [
      '"Inter"',
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'sans-serif',
    ].join(','),
    h1: { fontWeight: 700, letterSpacing: '-0.02em' },
    h2: { fontWeight: 700, letterSpacing: '-0.02em' },
    h3: { fontWeight: 700, letterSpacing: '-0.01em' },
    h4: { fontWeight: 700 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    button: { fontWeight: 600, textTransform: 'none' },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          backgroundColor: BG_PAGE,
          color: TEXT_LIGHT,
        },
        '::selection': {
          backgroundColor: ACCENT_MUTED,
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
          backgroundColor: BG_DARKGREY,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: BG_DARKGREY,
          border: `1px solid ${HAIRLINE}`,
          borderRadius: 12,
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 600,
          boxShadow: 'none',
        },
        contained: {
          boxShadow: 'none',
          '&:hover': { boxShadow: 'none', backgroundColor: ACCENT_HOVER },
        },
        outlined: {
          borderColor: DIVIDER,
          '&:hover': {
            borderColor: ACCENT_ORANGE,
            backgroundColor: ACCENT_MUTED,
          },
        },
        text: {
          '&:hover': { backgroundColor: 'rgba(255,255,255,0.06)' },
        },
      },
    },
    MuiTextField: {
      defaultProps: { variant: 'outlined' },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: BG_INPUT,
          borderRadius: 8,
          '& fieldset': { borderColor: DIVIDER },
          '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' },
          '&.Mui-focused fieldset': { borderColor: ACCENT_ORANGE },
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderBottom: `1px solid ${HAIRLINE}` },
        head: {
          color: TEXT_SECONDARY,
          fontWeight: 700,
          textTransform: 'uppercase',
          fontSize: '0.75rem',
          letterSpacing: '0.05em',
          backgroundColor: BG_INPUT,
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          '&:hover': { backgroundColor: 'rgba(255,255,255,0.03)' },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 600 },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          color: TEXT_SECONDARY,
          '&.Mui-selected': { color: ACCENT_ORANGE },
        },
      },
    },
  },
});

export default theme;
