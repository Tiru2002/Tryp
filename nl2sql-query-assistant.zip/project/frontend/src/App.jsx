import React, { useState } from 'react';
import { BrowserRouter } from 'react-router-dom';
import Box from '@mui/material/Box';
import AppRoutes from './routes/AppRoutes';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  const [isAdmin, setIsAdmin] = useState(localStorage.getItem('isAdmin') === 'true');
  const [userProfile, setUserProfile] = useState(
    localStorage.getItem('userProfile') ? JSON.parse(localStorage.getItem('userProfile')) : null
  );

  const handleLogout = () => {
    setToken(null);
    setIsAdmin(false);
    setUserProfile(null);
    localStorage.removeItem('token');
    localStorage.removeItem('isAdmin');
    localStorage.removeItem('userProfile');
  };

  return (
    <BrowserRouter>
      <Box sx={{ minHeight: '100svh', bgcolor: 'background.default' }}>
        <AppRoutes
          token={token}
          isAdmin={isAdmin}
          userProfile={userProfile}
          setUserProfile={setUserProfile}
          setToken={setToken}
          setIsAdmin={setIsAdmin}
          onLogout={handleLogout}
        />
      </Box>
    </BrowserRouter>
  );
}

export default App;
