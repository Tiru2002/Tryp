import React from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import ButtonBase from '@mui/material/ButtonBase';

const HistorySidebar = ({ history, setQuestion }) => {
  return (
    <Paper
      component="aside"
      elevation={0}
      sx={{
        width: 300,
        flexShrink: 0,
        p: 2.5,
        borderRadius: 3,
        border: '1px solid rgba(255,255,255,0.08)',
        maxHeight: '80vh',
        overflowY: 'auto',
      }}
    >
      <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2, pb: 1.5, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        Query History
      </Typography>

      {history.length === 0 ? (
        <Typography variant="body2" color="text.secondary">No queries run yet.</Typography>
      ) : (
        <Stack spacing={1.25}>
          {history.map((item) => (
            <ButtonBase
              key={item.id}
              onClick={() => setQuestion(item.question)}
              title="Click to load this query"
              sx={{
                display: 'block',
                textAlign: 'left',
                p: 1.5,
                borderRadius: 2,
                border: '1px solid rgba(255,255,255,0.08)',
                bgcolor: 'rgba(255,255,255,0.02)',
                transition: 'all 0.15s ease',
                '&:hover': {
                  borderColor: 'primary.main',
                  bgcolor: 'rgba(255,107,1,0.08)',
                  transform: 'translateX(3px)',
                },
              }}
            >
              <Box sx={{ width: '100%' }}>
                <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5, lineHeight: 1.4 }}>
                  {item.question}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {new Date(item.created_at).toLocaleString()}
                </Typography>
              </Box>
            </ButtonBase>
          ))}
        </Stack>
      )}
    </Paper>
  );
};

export default HistorySidebar;
