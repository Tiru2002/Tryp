import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Badge from '@mui/material/Badge';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemText from '@mui/material/ListItemText';
import StorageRoundedIcon from '@mui/icons-material/StorageRounded';
import SchemaRoundedIcon from '@mui/icons-material/SchemaRounded';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import AdminPanelSettingsRoundedIcon from '@mui/icons-material/AdminPanelSettingsRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';

const Header = ({
  isAdmin,
  onLogout,
  showSchema,
  onShowSchemaToggle,
  showHistory,
  onShowHistoryToggle,
  showProfilePanel,
  onProfileToggle,
  notificationCount = 0,
  notifications = [],
  notificationAnchorEl,
  onNotificationOpen,
  onNotificationClose,
  onNotificationSelect,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const isAdminView = location.pathname === '/admin';

  return (
    <AppBar
      position="static"
      elevation={0}
      sx={{
        bgcolor: 'background.paper',
        borderBottom: '1px solid rgba(255,255,255,0.08)',
      }}
    >
      <Toolbar sx={{ py: 1.25, gap: 2, flexWrap: 'wrap' }}>
        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ flex: 1, minWidth: 0 }}>
          <Box
            sx={{
              width: 36,
              height: 36,
              borderRadius: 1.5,
              display: 'grid',
              placeItems: 'center',
              bgcolor: 'rgba(255,107,1,0.14)',
              border: '1px solid rgba(255,107,1,0.35)',
              flexShrink: 0,
            }}
          >
            <StorageRoundedIcon sx={{ color: 'primary.main', fontSize: 20 }} />
          </Box>
          <Typography variant="h6" noWrap sx={{ fontWeight: 700 }}>
            NL-to-SQL Assistant
          </Typography>
          <Chip
            label="Local Inference"
            size="small"
            sx={{
              bgcolor: 'rgba(255,255,255,0.06)',
              color: 'text.primary',
              fontWeight: 500,
              display: { xs: 'none', sm: 'inline-flex' },
            }}
          />
        </Stack>

        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
          {!isAdminView && (
            <>
              <Button
                variant={showSchema ? 'contained' : 'outlined'}
                color="primary"
                size="small"
                startIcon={<SchemaRoundedIcon />}
                onClick={onShowSchemaToggle}
              >
                {showSchema ? 'Hide Schema' : 'Show Schema'}
              </Button>
              <Button
                variant={showHistory ? 'contained' : 'outlined'}
                color="primary"
                size="small"
                startIcon={<HistoryRoundedIcon />}
                onClick={onShowHistoryToggle}
              >
                {showHistory ? 'Hide History' : 'Show History'}
              </Button>
            </>
          )}

          {isAdmin && (
            <Button
              variant="contained"
              color="primary"
              size="small"
              startIcon={<AdminPanelSettingsRoundedIcon />}
              onClick={() => navigate(isAdminView ? '/query' : '/admin')}
            >
              {isAdminView ? 'Go to Query Workspace' : 'Go to Admin Panel'}
            </Button>
          )}

          <IconButton
            size="small"
            onClick={onProfileToggle}
            sx={{ ml: 0.5, color: showProfilePanel ? 'primary.main' : 'text.primary' }}
          >
            <AccountCircleRoundedIcon />
          </IconButton>

          <IconButton
            size="small"
            onClick={onNotificationOpen}
            sx={{ ml: 0.5, color: 'text.primary' }}
          >
            <Badge badgeContent={notificationCount} color="primary">
              <NotificationsRoundedIcon />
            </Badge>
          </IconButton>

          <Menu
            anchorEl={notificationAnchorEl}
            open={Boolean(notificationAnchorEl)}
            onClose={onNotificationClose}
            PaperProps={{
              sx: {
                bgcolor: 'background.paper',
                color: 'text.primary',
                minWidth: 320,
                border: '1px solid rgba(255,255,255,0.08)',
              }
            }}
          >
            {notifications.length === 0 ? (
              <MenuItem disabled>
                <ListItemText primary="No new notifications" />
              </MenuItem>
            ) : (
              notifications.map((note) => (
                <MenuItem key={note.id} onClick={() => onNotificationSelect(note.id)} sx={{ alignItems: 'flex-start' }}>
                  <ListItemText
                    primary={note.message}
                    secondary={new Date(note.created_at).toLocaleString()}
                    primaryTypographyProps={{ sx: { color: 'text.primary', fontWeight: 600 } }}
                    secondaryTypographyProps={{ sx: { color: 'text.secondary', fontSize: '0.75rem' } }}
                  />
                </MenuItem>
              ))
            )}
          </Menu>

          <Button
            variant="contained"
            color="primary"
            size="small"
            startIcon={<LogoutRoundedIcon />}
            onClick={onLogout}
          >
            Sign Out
          </Button>
        </Stack>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
