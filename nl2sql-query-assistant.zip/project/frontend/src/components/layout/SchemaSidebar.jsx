import React from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Chip from '@mui/material/Chip';
import CircularProgress from '@mui/material/CircularProgress';
import TableChartRoundedIcon from '@mui/icons-material/TableChartRounded';

const SchemaSidebar = ({ schema, loading }) => {
  return (
    <Paper
      component="aside"
      elevation={0}
      sx={{
        width: 300,
        flexShrink: 0,
        p: 2.5,
        borderRadius: 3,
        border: '1px solid rgba(255,255,255,0.08)',
        maxHeight: '80vh',
        overflowY: 'auto',
      }}
    >
      <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2, pb: 1.5, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        Database Schema
      </Typography>

      {loading && !schema && (
        <Stack alignItems="center" spacing={1.5} sx={{ py: 3 }}>
          <CircularProgress size={22} color="primary" />
          <Typography variant="body2" color="text.secondary">Loading database structure...</Typography>
        </Stack>
      )}

      {!loading && !schema && (
        <Typography variant="body2" color="text.secondary">No schema information available.</Typography>
      )}

      {schema && (
        <Stack spacing={1.5}>
          {Object.entries(schema).map(([tableName, columns]) => (
            <Box
              key={tableName}
              sx={{
                borderRadius: 2,
                overflow: 'hidden',
                border: '1px solid rgba(255,255,255,0.08)',
                bgcolor: 'rgba(255,255,255,0.02)',
              }}
            >
              <Stack
                direction="row"
                alignItems="center"
                spacing={1}
                sx={{ px: 1.5, py: 1, bgcolor: 'rgba(255,107,1,0.14)' }}
              >
                <TableChartRoundedIcon sx={{ fontSize: 16, color: 'primary.main' }} />
                <Typography variant="body2" fontWeight={700}>{tableName}</Typography>
              </Stack>
              <Box sx={{ py: 0.5 }}>
                {Array.isArray(columns) && columns.map((col, index) => (
                  <Stack
                    key={index}
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                    sx={{
                      px: 1.5,
                      py: 0.75,
                      borderBottom: index < columns.length - 1 ? '1px solid rgba(255,255,255,0.06)' : 'none',
                    }}
                  >
                    <Typography variant="caption" sx={{ fontWeight: 500 }}>{col.name}</Typography>
                    <Chip
                      label={col.type}
                      size="small"
                      variant="outlined"
                      sx={{ height: 20, fontSize: '0.65rem', fontFamily: 'monospace', color: 'text.secondary', borderColor: 'rgba(255,255,255,0.12)' }}
                    />
                  </Stack>
                ))}
              </Box>
            </Box>
          ))}
        </Stack>
      )}
    </Paper>
  );
};

export default SchemaSidebar;
