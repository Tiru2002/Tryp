import React, { useState, useEffect, useCallback } from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TablePagination from '@mui/material/TablePagination';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';

const RequestsTab = ({ token }) => {
  const [requests, setRequests] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [loading, setLoading] = useState(true);

  const fetchRequests = useCallback(async () => {
    setLoading(true);
    try {
      const skip = page * rowsPerPage;
      const res = await fetch(
        `http://localhost:8000/admin/requests?skip=${skip}&limit=${rowsPerPage}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.ok) {
        const data = await res.json();
        setRequests(data.items || []);
        setTotal(data.total || 0);
      }
    } catch (err) {
      console.error("Failed to load requests", err);
    } finally {
      setLoading(false);
    }
  }, [token, page, rowsPerPage]);

  useEffect(() => { fetchRequests(); }, [fetchRequests]);

  const handleChangePage = (event, newPage) => setPage(newPage);

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleUpdateStatus = async (id, newStatus) => {
    let body = { status: newStatus };
    if (newStatus === 'Denied') {
      const rejection_reason = window.prompt('Provide a brief rejection reason for the requester:');
      if (!rejection_reason) return;
      body.rejection_reason = rejection_reason;
    }

    try {
      const res = await fetch(`http://localhost:8000/admin/requests/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(body)
      });
      if (res.ok) {
        fetchRequests(); // Reload the current page to show the updated status
      }
    } catch (err) {
      console.error("Failed to update request", err);
    }
  };

  const exportToCSV = () => {
    if (requests.length === 0) return;

    const columns = ['id', 'username', 'requested_table', 'request_type', 'description', 'status', 'resolved_by', 'rejection_reason', 'created_at'];
    const headerRow = columns.join(',');
    const rows = requests.map((r) =>
      columns
        .map((col) => {
          const val = r[col];
          return val !== null && val !== undefined ? `"${String(val).replace(/"/g, '""')}"` : '';
        })
        .join(',')
    );
    const csvContent = [headerRow, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `access_requests_page_${page + 1}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const statusChipProps = (status) => {
    if (status === 'Approved') return { color: 'primary', variant: 'filled' };
    if (status === 'Denied') return { variant: 'outlined', sx: { color: 'text.secondary', borderColor: 'rgba(255,255,255,0.25)' } };
    return { variant: 'outlined', color: 'primary' };
  };

  return (
    <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2} sx={{ mb: 3 }}>
        <Box>
          <Typography variant="h6" fontWeight={700}>Request Management Console</Typography>
          <Typography variant="body2" color="text.secondary">
            Review employee requests for expanded database table access or system limit increases.
          </Typography>
        </Box>
        <Button
          variant="outlined"
          color="primary"
          size="small"
          startIcon={<DownloadRoundedIcon />}
          onClick={exportToCSV}
          disabled={requests.length === 0}
          sx={{ flexShrink: 0, whiteSpace: 'nowrap' }}
        >
          Download CSV
        </Button>
      </Stack>

      {loading ? (
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="center" sx={{ py: 3 }}>
          <CircularProgress size={18} color="primary" />
          <Typography color="text.secondary">Loading requests...</Typography>
        </Stack>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>User / Employee ID</TableCell>
                <TableCell>Requested Table</TableCell>
                <TableCell>Justification</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Resolved By</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {requests.map((req) => (
                <TableRow key={req.id}>
                  <TableCell sx={{ fontWeight: 700, verticalAlign: 'top' }}>{req.username}</TableCell>
                  <TableCell sx={{ verticalAlign: 'top' }}>{req.requested_table || 'N/A'}</TableCell>
                  <TableCell sx={{ maxWidth: 320, verticalAlign: 'top' }}>{req.description}</TableCell>
                  <TableCell sx={{ verticalAlign: 'top' }}>
                    <Chip label={req.status} size="small" {...statusChipProps(req.status)} />
                    {req.status === 'Denied' && req.rejection_reason && (
                      <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'primary.main' }}>
                        {req.rejection_reason}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell sx={{ verticalAlign: 'top' }}>{req.resolved_by || 'Pending'}</TableCell>
                  <TableCell align="right" sx={{ verticalAlign: 'top' }}>
                    {req.status === 'Pending' && (
                      <Stack direction="row" spacing={1} justifyContent="flex-end">
                        <Button
                          size="small"
                          variant="contained"
                          color="primary"
                          onClick={() => handleUpdateStatus(req.id, 'Approved')}
                        >
                          Approve
                        </Button>
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={() => handleUpdateStatus(req.id, 'Denied')}
                          sx={{ color: 'text.secondary', borderColor: 'rgba(255,255,255,0.2)' }}
                        >
                          Deny
                        </Button>
                      </Stack>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {requests.length === 0 && (
            <Typography color="text.secondary" sx={{ py: 3, textAlign: 'center' }}>
              No data access requests submitted yet.
            </Typography>
          )}
        </TableContainer>
      )}

      <TablePagination
        component="div"
        count={total}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[10, 25, 50, 100]}
        sx={{
          borderTop: '1px solid rgba(255,255,255,0.08)',
          mt: 1,
          '.MuiTablePagination-toolbar': { pl: 0 },
        }}
      />
    </Paper>
  );
};

export default RequestsTab;
