import React from 'react';
import { LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';

const usageData = [
  { date: 'Mon', queries: 45, errors: 2 },
  { date: 'Tue', queries: 52, errors: 4 },
  { date: 'Wed', queries: 38, errors: 1 },
  { date: 'Thu', queries: 65, errors: 5 },
  { date: 'Fri', queries: 48, errors: 2 },
];

const roleData = [
  { name: 'Standard Users', value: 85 },
  { name: 'Admins', value: 15 },
];

// Two-tone chart palette using only the brand orange plus a translucent
// white, so multi-series charts stay inside the 3-color brief.
const COLORS = ['#FF6B01', 'rgba(255,255,255,0.35)'];
const axisStyle = { stroke: 'rgba(255,255,255,0.6)', tick: { fill: 'rgba(255,255,255,0.6)', fontSize: 12 } };
const tooltipStyle = { background: '#2C2C2C', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#FFFFFF' };

const AnalyticsTab = ({ token }) => {
  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)', height: '100%' }}>
          <Typography variant="h6" fontWeight={700}>Query Volume (Last 5 Days)</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Total queries vs failures.</Typography>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <LineChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="date" {...axisStyle} />
                <YAxis {...axisStyle} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.8)' }} />
                <Line type="monotone" dataKey="queries" stroke="#FF6B01" strokeWidth={2} name="Total Queries" dot={{ r: 3 }} />
                <Line type="monotone" dataKey="errors" stroke="#FFFFFF" strokeOpacity={0.55} strokeWidth={2} name="Failed Generations" dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)', height: '100%' }}>
          <Typography variant="h6" fontWeight={700}>User Role Distribution</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Active accounts by permission level.</Typography>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={roleData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value" label>
                  {roleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="#353535" />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend verticalAlign="bottom" height={36} wrapperStyle={{ color: 'rgba(255,255,255,0.8)' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default AnalyticsTab;
