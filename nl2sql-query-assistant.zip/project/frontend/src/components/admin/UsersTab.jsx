import React, { useState, useEffect } from 'react';
import Stack from '@mui/material/Stack';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Chip from '@mui/material/Chip';

const UsersTab = ({ token }) => {
  const [users, setUsers] = useState([]);
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);

  const fetchUsers = async () => {
    try {
      const res = await fetch('http://localhost:8000/admin/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) setUsers(await res.json());
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchUsers(); }, [token]);

  const handleProvision = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:8000/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ username: newUsername, email: newEmail, is_admin: isAdmin })
      });
      if (res.ok) {
        setNewUsername(''); setNewEmail(''); setIsAdmin(false);
        fetchUsers();
      }
    } catch (err) { console.error(err); }
  };

  const handleRevoke = async (id) => {
    if (!window.confirm("Are you sure you want to revoke this user's access?")) return;
    try {
      const res = await fetch(`http://localhost:8000/admin/users/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) fetchUsers();
    } catch (err) { console.error(err); }
  };

  return (
    <Stack direction={{ xs: 'column', lg: 'row' }} spacing={3}>
      <Paper elevation={0} sx={{ flex: 2, p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
        <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Active Users</Typography>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Username</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Role</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map(u => (
                <TableRow key={u.id}>
                  <TableCell>{u.id}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{u.username}</TableCell>
                  <TableCell>{u.status}</TableCell>
                  <TableCell>
                    <Chip
                      label={u.is_admin ? 'Admin' : 'User'}
                      size="small"
                      variant={u.is_admin ? 'filled' : 'outlined'}
                      color={u.is_admin ? 'primary' : 'default'}
                    />
                  </TableCell>
                  <TableCell align="right">
                    <Button size="small" color="inherit" sx={{ color: 'text.secondary', textDecoration: 'underline', '&:hover': { color: 'primary.main' } }} onClick={() => handleRevoke(u.id)}>
                      Revoke
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {users.length === 0 && (
            <Typography color="text.secondary" sx={{ mt: 2, textAlign: 'center' }}>No users found.</Typography>
          )}
        </TableContainer>
      </Paper>

      <Paper elevation={0} sx={{ flex: 1, p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)', minWidth: { lg: 300 } }}>
        <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Provision New User</Typography>
        <Stack component="form" onSubmit={handleProvision} spacing={2}>
          <TextField
            label="Employee ID (Username)"
            value={newUsername}
            onChange={e => setNewUsername(e.target.value)}
            required
            fullWidth
            size="small"
          />
          <TextField
            label="Email Address"
            type="email"
            value={newEmail}
            onChange={e => setNewEmail(e.target.value)}
            required
            fullWidth
            size="small"
          />
          <FormControlLabel
            control={<Checkbox checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} color="primary" />}
            label="Grant Admin Privileges"
          />
          <Button type="submit" variant="contained" color="primary" fullWidth>
            Authorize User
          </Button>
        </Stack>
      </Paper>
    </Stack>
  );
};

export default UsersTab;
