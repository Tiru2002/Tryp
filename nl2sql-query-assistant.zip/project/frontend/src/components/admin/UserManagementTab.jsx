import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Alert from '@mui/material/Alert';
import Chip from '@mui/material/Chip';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import PersonAddAltRoundedIcon from '@mui/icons-material/PersonAddAltRounded';

const UserManagementTab = ({ token }) => {
  const [users, setUsers] = useState([]);
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newIsAdmin, setNewIsAdmin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const fetchUsers = async () => {
    try {
      const res = await fetch('http://localhost:8000/admin/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (err) {
      console.error("Failed to load users", err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [token]);

  const handleProvisionUser = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const res = await fetch('http://localhost:8000/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          username: newUsername,
          email: newEmail,
          is_admin: newIsAdmin
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Failed to provision user.');

      setMessage(data.message);
      setNewUsername('');
      setNewEmail('');
      setNewIsAdmin(false);
      fetchUsers();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (id, username) => {
    if (!window.confirm(`Are you sure you want to revoke access for ${username}?`)) return;

    try {
      const res = await fetch(`http://localhost:8000/admin/users/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) fetchUsers();
    } catch (err) {
      console.error("Failed to revoke access", err);
    }
  };

  return (
    <Paper elevation={0} sx={{ maxWidth: 1000, p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h6" fontWeight={700}>Access Management</Typography>
        <Typography variant="body2" color="text.secondary">
          Pre-provision employee IDs to allow them to claim their accounts via email.
        </Typography>
      </Box>

      <Paper
        elevation={0}
        sx={{ p: 3, mb: 3, borderRadius: 2, bgcolor: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}
      >
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Authorize New Employee</Typography>

        <Stack
          component="form"
          onSubmit={handleProvisionUser}
          direction={{ xs: 'column', md: 'row' }}
          spacing={2}
          alignItems={{ md: 'flex-end' }}
        >
          <TextField
            label="Employee ID"
            placeholder="e.g., 4838"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            required
            size="small"
            sx={{ flex: 1, minWidth: 180 }}
          />
          <TextField
            label="Corporate Email"
            type="email"
            placeholder="emp@company.com"
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            required
            size="small"
            sx={{ flex: 1.5, minWidth: 220 }}
          />
          <Select
            value={newIsAdmin}
            onChange={(e) => setNewIsAdmin(e.target.value === 'true' || e.target.value === true)}
            size="small"
            sx={{ minWidth: 160 }}
          >
            <MenuItem value={false}>Standard User</MenuItem>
            <MenuItem value={true}>Administrator</MenuItem>
          </Select>

          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={loading}
            startIcon={<PersonAddAltRoundedIcon />}
            sx={{ height: 40, whiteSpace: 'nowrap' }}
          >
            {loading ? 'Authorizing...' : 'Grant Access'}
          </Button>
        </Stack>

        {error && <Alert severity="error" variant="outlined" sx={{ mt: 2 }}>{error}</Alert>}
        {message && <Alert severity="success" variant="outlined" sx={{ mt: 2 }}>{message}</Alert>}
      </Paper>

      <TableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Employee Identifier</TableCell>
              <TableCell>System Role</TableCell>
              <TableCell>Account Status</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map(u => (
              <TableRow key={u.id}>
                <TableCell sx={{ color: 'text.secondary' }}>#{u.id}</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>{u.username}</TableCell>
                <TableCell>
                  <Chip
                    label={u.is_admin ? 'Admin' : 'User'}
                    size="small"
                    color={u.is_admin ? 'primary' : 'default'}
                    variant={u.is_admin ? 'filled' : 'outlined'}
                  />
                </TableCell>
                <TableCell>
                  <Typography variant="body2" sx={{ color: u.status === 'Active' ? 'primary.main' : 'text.secondary' }}>
                    {u.status}
                  </Typography>
                </TableCell>
                <TableCell align="right">
                  <Button
                    size="small"
                    onClick={() => handleRevoke(u.id, u.username)}
                    sx={{ color: 'text.secondary', textDecoration: 'underline', '&:hover': { color: 'primary.main' } }}
                  >
                    Revoke
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {users.length === 0 && (
          <Typography color="text.secondary" sx={{ mt: 2, textAlign: 'center' }}>No users found.</Typography>
        )}
      </TableContainer>
    </Paper>
  );
};

export default UserManagementTab;
