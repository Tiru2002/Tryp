import React, { useState, useEffect, useCallback } from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TablePagination from '@mui/material/TablePagination';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import CircularProgress from '@mui/material/CircularProgress';

const LogsTab = ({ token }) => {
  const [logs, setLogs] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0); // MUI TablePagination is 0-indexed
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [loading, setLoading] = useState(true);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const skip = page * rowsPerPage;
      const res = await fetch(
        `http://localhost:8000/admin/logs?skip=${skip}&limit=${rowsPerPage}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.ok) {
        const data = await res.json();
        setLogs(data.items || []);
        setTotal(data.total || 0);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [token, page, rowsPerPage]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const handleChangePage = (event, newPage) => setPage(newPage);

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Box sx={{ mb: 2 }}>
        <Typography variant="h6" fontWeight={700}>System Audit Logs</Typography>
        <Typography variant="body2" color="text.secondary">
          Global record of natural language queries and the SQL generated to answer them.
        </Typography>
      </Box>

      <TableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ whiteSpace: 'nowrap' }}>Time</TableCell>
              <TableCell>User</TableCell>
              <TableCell>Question</TableCell>
              <TableCell>Generated SQL</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {logs.map(log => (
              <TableRow key={log.id}>
                <TableCell sx={{ fontSize: '0.8rem', whiteSpace: 'nowrap', verticalAlign: 'top' }}>
                  {new Date(log.created_at).toLocaleString()}
                </TableCell>
                <TableCell sx={{ fontWeight: 600, verticalAlign: 'top' }}>{log.username}</TableCell>
                <TableCell sx={{ verticalAlign: 'top' }}>{log.question}</TableCell>
                <TableCell sx={{ verticalAlign: 'top' }}>
                  <Box
                    component="code"
                    sx={{
                      display: 'block',
                      fontFamily: 'monospace',
                      fontSize: '0.8rem',
                      color: 'primary.main',
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                    }}
                  >
                    {log.generated_sql}
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {loading && (
          <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="center" sx={{ py: 3 }}>
            <CircularProgress size={18} color="primary" />
            <Typography color="text.secondary" variant="body2">Loading logs...</Typography>
          </Stack>
        )}

        {!loading && logs.length === 0 && (
          <Typography color="text.secondary" sx={{ py: 3, textAlign: 'center' }}>
            No query logs found.
          </Typography>
        )}
      </TableContainer>

      <TablePagination
        component="div"
        count={total}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[10, 25, 50, 100]}
        sx={{
          borderTop: '1px solid rgba(255,255,255,0.08)',
          mt: 1,
          '.MuiTablePagination-toolbar': { pl: 0 },
        }}
      />
    </Paper>
  );
};

export default LogsTab;
