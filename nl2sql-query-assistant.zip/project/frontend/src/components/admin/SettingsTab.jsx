import React, { useState, useEffect } from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';

const SettingsTab = ({ token }) => {
  const [settings, setSettings] = useState({ row_limit: 500, system_prompt: '', allowed_tables: [] });
  const [allTables, setAllTables] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [setRes, tabRes] = await Promise.all([
          fetch('http://localhost:8000/admin/settings', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('http://localhost:8000/admin/tables', { headers: { Authorization: `Bearer ${token}` } })
        ]);
        if (setRes.ok) setSettings(await setRes.json());
        if (tabRes.ok) setAllTables(await tabRes.json());
      } catch (err) { console.error(err); }
    };
    fetchData();
  }, [token]);

  const handleToggleTable = (tableName) => {
    setSettings(prev => {
      const allowed = prev.allowed_tables.includes(tableName)
        ? prev.allowed_tables.filter(t => t !== tableName)
        : [...prev.allowed_tables, tableName];
      return { ...prev, allowed_tables: allowed };
    });
  };

  const handleSave = async () => {
    try {
      await fetch('http://localhost:8000/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(settings)
      });
      alert('Configuration saved successfully.');
    } catch (err) { console.error(err); }
  };

  return (
    <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Governance Settings</Typography>

      <Box sx={{ mb: 3 }}>
        <TextField
          label="Max Row Limit"
          type="number"
          value={settings.row_limit}
          onChange={e => setSettings({ ...settings, row_limit: parseInt(e.target.value) })}
          size="small"
          sx={{ width: 220 }}
        />
      </Box>

      <Box sx={{ mb: 3 }}>
        <TextField
          label="System Prompt Directive"
          value={settings.system_prompt}
          onChange={e => setSettings({ ...settings, system_prompt: e.target.value })}
          multiline
          minRows={4}
          fullWidth
        />
      </Box>

      <Box sx={{ mb: 3 }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Dynamic Table Visibility</Typography>
        <Grid container spacing={1}>
          {allTables.map(table => (
            <Grid item xs={12} sm={6} md={4} key={table}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={settings.allowed_tables.includes(table)}
                    onChange={() => handleToggleTable(table)}
                    color="primary"
                  />
                }
                label={table}
              />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Button variant="contained" color="primary" size="large" onClick={handleSave}>
        Save Configuration
      </Button>
    </Paper>
  );
};

export default SettingsTab;
