import React, { useState, useEffect } from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';

const AuditLogsTab = ({ token }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await fetch('http://localhost:8000/admin/logs?limit=50', {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          // /admin/logs now returns a paginated envelope: { total, skip, limit, items }
          setLogs(data.items || []);
        }
      } catch (err) {
        console.error("Failed to fetch audit logs", err);
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, [token]);

  const exportToCSV = () => {
    if (logs.length === 0) return;

    const columns = ['id', 'username', 'question', 'generated_sql', 'created_at'];
    const headerRow = columns.join(',');
    const rows = logs.map((log) =>
      columns
        .map((col) => {
          const val = log[col];
          return val !== null && val !== undefined ? `"${String(val).replace(/"/g, '""')}"` : '';
        })
        .join(',')
    );
    const csvContent = [headerRow, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'audit_logs.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Paper elevation={0} sx={{ p: 3, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2} sx={{ mb: 3 }}>
        <Box>
          <Typography variant="h6" fontWeight={700}>System Audit Logs</Typography>
          <Typography variant="body2" color="text.secondary">
            Global record of all natural language queries and generated SQL.
          </Typography>
        </Box>
        <Button
          variant="outlined"
          color="primary"
          size="small"
          startIcon={<DownloadRoundedIcon />}
          onClick={exportToCSV}
          disabled={logs.length === 0}
          sx={{ flexShrink: 0, whiteSpace: 'nowrap' }}
        >
          Download CSV
        </Button>
      </Stack>

      {loading ? (
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="center" sx={{ py: 3 }}>
          <CircularProgress size={18} color="primary" />
          <Typography color="text.secondary">Loading logs...</Typography>
        </Stack>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ whiteSpace: 'nowrap' }}>Timestamp</TableCell>
                <TableCell>User</TableCell>
                <TableCell>Natural Language Query</TableCell>
                <TableCell>Generated SQL</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell sx={{ whiteSpace: 'nowrap', verticalAlign: 'top' }}>
                    {new Date(log.created_at).toLocaleString()}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 700, verticalAlign: 'top' }}>{log.username}</TableCell>
                  <TableCell sx={{ verticalAlign: 'top' }}>{log.question}</TableCell>
                  <TableCell sx={{ verticalAlign: 'top' }}>
                    <Box
                      component="code"
                      sx={{
                        display: 'block',
                        bgcolor: 'rgba(255,255,255,0.05)',
                        px: 1, py: 0.5,
                        borderRadius: 1,
                        fontSize: '0.8rem',
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-word',
                      }}
                    >
                      {log.generated_sql}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {logs.length === 0 && (
            <Typography color="text.secondary" sx={{ py: 3, textAlign: 'center' }}>
              No query logs found.
            </Typography>
          )}
        </TableContainer>
      )}
    </Paper>
  );
};

export default AuditLogsTab;
