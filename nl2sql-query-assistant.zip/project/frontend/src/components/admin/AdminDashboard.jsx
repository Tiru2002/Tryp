import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import PeopleAltRoundedIcon from '@mui/icons-material/PeopleAltRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import ReceiptLongRoundedIcon from '@mui/icons-material/ReceiptLongRounded';

import Header from '../layout/Header';
import UsersTab from './UsersTab';
import LogsTab from './LogsTab';
import SettingsTab from './SettingsTab';
import RequestsTab from './RequestsTab';

const AdminDashboard = ({ token, onLogout }) => {
  const [activeTab, setActiveTab] = useState('users');

  return (
    <Box sx={{ minHeight: '100svh', bgcolor: 'background.default' }}>
      <Header isAdmin={true} onLogout={onLogout} />

      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Administrative Governance Panel
        </Typography>

        <Tabs
          value={activeTab}
          onChange={(e, val) => setActiveTab(val)}
          textColor="primary"
          indicatorColor="primary"
          sx={{
            mb: 3,
            borderBottom: '1px solid rgba(255,255,255,0.08)',
            '& .MuiTabs-indicator': { height: 3, borderRadius: 3 },
          }}
        >
          <Tab value="users" label="User Management" icon={<PeopleAltRoundedIcon />} iconPosition="start" />
          <Tab value="settings" label="Governance Settings" icon={<TuneRoundedIcon />} iconPosition="start" />
          <Tab value="requests" label="Access Requests" icon={<FactCheckRoundedIcon />} iconPosition="start" />
          <Tab value="logs" label="Audit Trail Logs" icon={<ReceiptLongRoundedIcon />} iconPosition="start" />
        </Tabs>

        <Box component="main">
          {activeTab === 'users' && <UsersTab token={token} />}
          {activeTab === 'settings' && <SettingsTab token={token} />}
          {activeTab === 'requests' && <RequestsTab token={token} />}
          {activeTab === 'logs' && <LogsTab token={token} />}
        </Box>
      </Container>
    </Box>
  );
};

export default AdminDashboard;
