import React from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';

const InsightSummary = ({ summary }) => {
  if (!summary) return null;

  return (
    <Paper
      elevation={0}
      sx={{
        p: 2.5,
        mb: 2.5,
        borderRadius: 3,
        bgcolor: 'rgba(255,107,1,0.10)',
        border: '1px solid rgba(255,107,1,0.3)',
      }}
    >
      <Stack direction="row" spacing={1.5} alignItems="flex-start">
        <AutoAwesomeRoundedIcon sx={{ color: 'primary.main', fontSize: 20, mt: 0.25 }} />
        <Typography variant="body2" sx={{ lineHeight: 1.6 }}>
          <Typography component="span" fontWeight={700}>AI Insight: </Typography>
          {summary}
        </Typography>
      </Stack>
    </Paper>
  );
};

export default InsightSummary;
