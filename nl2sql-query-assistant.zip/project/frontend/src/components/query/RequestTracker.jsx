import React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';

const steps = ['Submitted & Logged', 'Under Review by Administration', 'Final Decision State'];

const RequestTracker = ({ open, onClose, request }) => {
  const activeStep = request?.status === 'Approved' ? 2 : request?.status === 'Denied' ? 2 : 1;
  const decisionText = request?.status === 'Approved'
    ? `Approved by ${request.resolved_by || 'Administration'}`
    : request?.status === 'Denied'
      ? `Denied by ${request.resolved_by || 'Administration'}`
      : 'Your access request is currently under review.';

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ bgcolor: 'background.paper', color: 'text.primary' }}>
        Request Tracker
      </DialogTitle>
      <DialogContent sx={{ bgcolor: 'background.default' }}>
        <Stepper activeStep={activeStep} orientation="vertical" sx={{ py: 1 }}>
          {steps.map((label, index) => (
            <Step key={label} expanded>
              <StepLabel>
                <Typography fontWeight={700} sx={{ color: index <= activeStep ? 'primary.main' : 'text.secondary' }}>
                  {label}
                </Typography>
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box sx={{ mt: 2, p: 2, bgcolor: 'rgba(255,255,255,0.04)', borderRadius: 2, border: '1px solid rgba(255,255,255,0.08)' }}>
          <Stack spacing={1}>
            <Typography variant="subtitle2" color="text.secondary">
              Request ID: {request?.id || 'N/A'}
            </Typography>
            <Typography variant="body1" fontWeight={700}>
              {decisionText}
            </Typography>
            {request?.status === 'Denied' && request?.rejection_reason && (
              <Typography variant="body2" sx={{ color: 'primary.main' }}>
                {request.rejection_reason}
              </Typography>
            )}
            <Typography variant="caption" color="text.secondary">
              Requested table: {request?.requested_table || 'Not specified'}
            </Typography>
          </Stack>
        </Box>
      </DialogContent>
      <DialogActions sx={{ bgcolor: 'background.paper' }}>
        <Button onClick={onClose} color="primary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default RequestTracker;
