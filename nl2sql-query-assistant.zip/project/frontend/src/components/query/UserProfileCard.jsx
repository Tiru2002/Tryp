import React from 'react';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';

const UserProfileCard = ({ profile, metrics, onRequestClick }) => {
  const displayName = profile?.username || 'User';
  const initials = displayName
    .split(' ')
    .map((segment) => segment.charAt(0).toUpperCase())
    .slice(0, 2)
    .join('');

  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 3,
        border: '1px solid rgba(255,255,255,0.08)',
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
      }}
    >
      <Stack spacing={2} alignItems="center" textAlign="center">
        <Avatar
          sx={{
            width: 88,
            height: 88,
            bgcolor: 'primary.main',
            color: 'background.paper',
            fontSize: '1.75rem',
            fontWeight: 700,
          }}
        >
          {initials}
        </Avatar>
        <Box>
          <Typography variant="h6" fontWeight={700}>
            {profile?.username || 'Employee'}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {profile?.department_title || 'Business Intelligence'}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {profile?.organization || 'Enterprise Analytics'} • {profile?.region || 'Global'}
          </Typography>
        </Box>
      </Stack>

      <Divider sx={{ borderColor: 'rgba(255,255,255,0.08)' }} />

      <Grid container spacing={1}>
        {[
          { label: 'Authorized Tables', value: profile?.allowed_tables_count ?? 0 },
          { label: 'Queries Executed', value: metrics?.queries_executed ?? 0 },
          { label: 'Pending Approvals', value: metrics?.pending_approvals ?? 0 },
        ].map((item) => (
          <Grid key={item.label} item xs={12} sm={4}>
            <Paper
              elevation={0}
              sx={{
                p: 2,
                bgcolor: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 2,
                minHeight: 88,
              }}
            >
              <Typography variant="h5" fontWeight={700}>
                {item.value}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {item.label}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Button
        variant="contained"
        color="primary"
        fullWidth
        onClick={onRequestClick}
        sx={{ mt: 1, py: 1.5, fontSize: '0.95rem' }}
      >
        + Request Additional Access
      </Button>
    </Paper>
  );
};

export default UserProfileCard;
