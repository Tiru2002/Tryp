import React from 'react';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';

const QueryInput = ({ question, setQuestion, onSubmit, loading }) => {
  return (
    <Paper
      elevation={0}
      sx={{ p: 2, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}
    >
      <Stack component="form" direction={{ xs: 'column', sm: 'row' }} spacing={1.5} onSubmit={onSubmit}>
        <TextField
          fullWidth
          placeholder="Ask a question about your data (e.g., 'Show me top 5 customers by revenue')"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          disabled={loading}
          required
        />
        <Button
          type="submit"
          variant="contained"
          color="primary"
          size="large"
          disabled={loading || !question.trim()}
          startIcon={<SearchRoundedIcon />}
          sx={{ px: 3, whiteSpace: 'nowrap' }}
        >
          {loading ? 'Processing...' : 'Run Query'}
        </Button>
      </Stack>
    </Paper>
  );
};

export default QueryInput;
