import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from 'recharts';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';

const DynamicChart = ({ data }) => {
  if (!data || data.length === 0 || data.length > 50) return null; // Prevent charting massive datasets

  // Auto-detect the best columns for charting
  const keys = Object.keys(data[0]);
  const stringKeys = keys.filter(k => typeof data[0][k] === 'string');
  const numKeys = keys.filter(k => typeof data[0][k] === 'number');

  // We need at least one numeric column to make a meaningful chart
  if (numKeys.length === 0) return null;

  const xAxisKey = stringKeys.length > 0 ? stringKeys[0] : keys[0];
  const barKey = numKeys[0];

  return (
    <Paper
      elevation={0}
      sx={{ p: 2.5, mb: 2.5, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}
    >
      <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1.5 }}>
        Data Visualization
      </Typography>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
            <XAxis dataKey={xAxisKey} stroke="rgba(255,255,255,0.6)" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }} />
            <YAxis stroke="rgba(255,255,255,0.6)" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }} />
            <Tooltip
              cursor={{ fill: 'rgba(255,255,255,0.05)' }}
              contentStyle={{ background: '#2C2C2C', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#FFFFFF' }}
            />
            <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.8)' }} />
            <Bar dataKey={barKey} fill="#FF6B01" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Paper>
  );
};

export default DynamicChart;
