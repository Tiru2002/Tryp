import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Alert from '@mui/material/Alert';
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
import LinearProgress from '@mui/material/LinearProgress';
import Drawer from '@mui/material/Drawer';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';

// Sub-components
import Header from '../layout/Header';
import SchemaSidebar from '../layout/SchemaSidebar';
import HistorySidebar from '../layout/HistorySidebar';
import QueryInput from './QueryInput';
import SqlViewer from './SqlViewer';
import InsightSummary from './InsightSummary';
import DynamicChart from './DynamicChart';
import ResultsTable from './ResultsTable';
import UserProfileCard from './UserProfileCard';
import RequestTracker from './RequestTracker';
import ErrorBoundary from '../common/ErrorBoundary';
const QueryDashboard = ({ token, isAdmin, onLogout, userProfile }) => {
  const API_BASE = 'http://localhost:8000';

  // State
  const [question, setQuestion] = useState('');
  const [sqlQuery, setSqlQuery] = useState('');
  const [results, setResults] = useState([]);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Sidebars
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);

  const [schema, setSchema] = useState(null);
  const [showSchema, setShowSchema] = useState(false);
  const [schemaLoading, setSchemaLoading] = useState(false);
  const [userMetrics, setUserMetrics] = useState({ queries_executed: 0, pending_approvals: 0 });
  const [requests, setRequests] = useState([]);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [trackerOpen, setTrackerOpen] = useState(false);
  const [showProfilePanel, setShowProfilePanel] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);

  // Initial Fetch
  useEffect(() => {
    fetchSchema();
    fetchHistory();
    fetchUserProfile();
    fetchUserRequests();
    fetchNotifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchSchema = async () => {
    setSchemaLoading(true);
    try {
      const res = await fetch(`${API_BASE}/schema`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setSchema(data);
      }
    } catch (err) {
      console.error("Failed to load schema", err);
    }
    setSchemaLoading(false);
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch(`${API_BASE}/history?limit=10`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (err) {
      console.error("Failed to load history", err);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const res = await fetch(`${API_BASE}/profile`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUserMetrics(data.metrics || { queries_executed: 0, pending_approvals: 0 });
      }
    } catch (err) {
      console.error("Failed to load profile metrics", err);
    }
  };

  const fetchUserRequests = async () => {
    try {
      const res = await fetch(`${API_BASE}/requests`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setRequests(data);
      }
    } catch (err) {
      console.error("Failed to load requests", err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch(`${API_BASE}/notifications`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (err) {
      console.error("Failed to load notifications", err);
    }
  };

  const handleOpenNotifications = (event) => {
    setNotificationAnchorEl(event.currentTarget);
    setShowProfilePanel(false);
  };

  const handleCloseNotifications = () => {
    setNotificationAnchorEl(null);
  };

  const handleToggleProfilePanel = () => {
    setShowProfilePanel((prev) => !prev);
    setNotificationAnchorEl(null);
  };

  const handleToggleSchema = () => {
    setShowProfilePanel(false);
    setShowHistory(false);
    setShowSchema((prev) => !prev);
  };

  const handleToggleHistory = () => {
    setShowProfilePanel(false);
    setShowSchema(false);
    setShowHistory((prev) => !prev);
  };

  const markNotificationRead = async (notificationId) => {
    try {
      const res = await fetch(`${API_BASE}/notifications/${notificationId}/read`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        await fetchNotifications();
      }
    } catch (err) {
      console.error('Failed to mark notification read', err);
    }
  };

  const handleQuerySubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSqlQuery('');
    setResults([]);
    setSummary('');

    try {
      const res = await fetch(`${API_BASE}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ question })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.detail || 'Query execution failed');
      }

      const data = await res.json();
      setSqlQuery(data.sql);
      setResults(data.results);
      setSummary(data.summary);

      fetchHistory(); // Refresh history sidebar
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // --- Request Management Submission ---
  const handleSubmitRequest = async () => {
    const requestedTable = window.prompt("Which table do you need access to? (e.g., performance_reviews)");
    if (!requestedTable) return;

    const reason = window.prompt("Please describe why you need access to this table.");
    if (!reason) return;

    try {
      const res = await fetch(`${API_BASE}/requests`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          request_type: "Table Access",
          requested_table: requestedTable,
          description: reason
        })
      });

      if (res.ok) {
        await fetchUserRequests();
        await fetchUserProfile();
        alert("Request submitted to administration successfully.");
      } else {
        const errorData = await res.json();
        alert(`Failed to submit: ${errorData.detail || "Unknown error"}`);
      }
    } catch (err) {
      console.error(err);
      alert("A network error occurred while submitting your request.");
    }
  };

  const handleOpenTracker = (request) => {
    setSelectedRequest(request);
    setTrackerOpen(true);
  };

  const handleCloseTracker = () => {
    setTrackerOpen(false);
    setSelectedRequest(null);
  };

  return (
    <Box sx={{ minHeight: '100svh', bgcolor: 'background.default' }}>
      <Header
        isAdmin={isAdmin}
        onLogout={onLogout}
        showSchema={showSchema}
        onShowSchemaToggle={handleToggleSchema}
        showHistory={showHistory}
        onShowHistoryToggle={handleToggleHistory}
        showProfilePanel={showProfilePanel}
        onProfileToggle={handleToggleProfilePanel}
        notificationCount={notifications.length}
        notifications={notifications}
        notificationAnchorEl={notificationAnchorEl}
        onNotificationOpen={handleOpenNotifications}
        onNotificationClose={handleCloseNotifications}
        onNotificationSelect={markNotificationRead}
      />

      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} alignItems="flex-start" sx={{ p: { xs: 2, md: 3 } }}>

        <Box component="main" sx={{ flex: 1, minWidth: 0, width: '100%' }}>
          <QueryInput
            question={question}
            setQuestion={setQuestion}
            onSubmit={handleQuerySubmit}
            loading={loading}
          />

          {!showSchema && (
            <Box sx={{ mt: 1, textAlign: 'right' }}>
              <Link
                component="button"
                type="button"
                onClick={handleSubmitRequest}
                underline="hover"
                sx={{ fontSize: '0.85rem', color: 'text.secondary', '&:hover': { color: 'primary.main' } }}
              >
                Missing a table? Request access.
              </Link>
            </Box>
          )}

          {error && (
            <Alert severity="error" variant="outlined" sx={{ mt: 2 }}>
              <strong>Error:</strong> {error}
            </Alert>
          )}

          {loading && (
            <Box sx={{ mt: 3 }}>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1, textAlign: 'center' }}>
                Translating query and executing against database...
              </Typography>
              <LinearProgress color="primary" />
            </Box>
          )}

          {!loading && sqlQuery && (
            <Stack spacing={0} sx={{ mt: 3 }}>
              <InsightSummary summary={summary} />
              <SqlViewer sqlQuery={sqlQuery} />

              <ErrorBoundary label="the chart">
                <DynamicChart data={results} />
              </ErrorBoundary>

              <ErrorBoundary label="the results table">
                <ResultsTable results={results} />
              </ErrorBoundary>

              {results.length === 0 && (
                <Typography color="text.secondary" sx={{ mt: 1, textAlign: 'center' }}>
                  No results found for this query.
                </Typography>
              )}
            </Stack>
          )}
        </Box>

        {showSchema && (
          <Box sx={{ width: { xs: '100%', md: 300 }, flexShrink: 0 }}>
            <SchemaSidebar schema={schema} loading={schemaLoading} />
          </Box>
        )}

        {showHistory && (
          <Box sx={{ width: { xs: '100%', md: 300 }, flexShrink: 0 }}>
            <HistorySidebar history={history} setQuestion={setQuestion} />
          </Box>
        )}

      </Stack>

      <Drawer
        anchor="right"
        open={showProfilePanel}
        onClose={handleToggleProfilePanel}
        PaperProps={{
          sx: {
            width: { xs: '100%', sm: 360 },
            bgcolor: 'background.paper',
            borderLeft: '1px solid rgba(255,255,255,0.08)',
          },
        }}
      >
        <Box sx={{ p: 3, minHeight: '100vh' }}>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
            My Profile
          </Typography>
          <UserProfileCard
            profile={userProfile || { username: 'Employee', department_title: '', organization: '', region: '', allowed_tables_count: 0 }}
            metrics={userMetrics}
            onRequestClick={handleSubmitRequest}
          />

          <Divider sx={{ my: 3, borderColor: 'rgba(255,255,255,0.08)' }} />

          <Typography
            variant="subtitle2"
            color="text.secondary"
            sx={{ mb: 1.5, textTransform: 'uppercase', letterSpacing: '0.08em' }}
          >
            Request tracker
          </Typography>
          <Stack spacing={1.25}>
            {requests.slice(0, 4).map((request) => (
              <Box
                key={request.id}
                onClick={() => handleOpenTracker(request)}
                sx={{
                  p: 2,
                  borderRadius: 2,
                  border: '1px solid rgba(255,255,255,0.08)',
                  bgcolor: 'rgba(255,255,255,0.02)',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  '&:hover': { borderColor: 'primary.main', bgcolor: 'rgba(255,107,1,0.06)' },
                }}
              >
                <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1.5}>
                  <Typography variant="body2" fontWeight={700} noWrap>
                    {request.requested_table}
                  </Typography>
                  <Chip
                    label={request.status}
                    size="small"
                    variant={request.status === 'Approved' ? 'filled' : 'outlined'}
                    color={request.status === 'Approved' ? 'primary' : 'default'}
                    sx={{ height: 20, fontSize: '0.7rem', flexShrink: 0 }}
                  />
                </Stack>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                  {new Date(request.created_at).toLocaleDateString()}
                </Typography>
              </Box>
            ))}
            {requests.length === 0 && (
              <Typography variant="body2" color="text.secondary">
                No open requests.
              </Typography>
            )}
          </Stack>
        </Box>
      </Drawer>

      <RequestTracker
        open={trackerOpen}
        onClose={handleCloseTracker}
        request={selectedRequest}
      />
    </Box>
  );
};

export default QueryDashboard;
