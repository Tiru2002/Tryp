import React from 'react';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';

const SqlViewer = ({ sqlQuery }) => {
  if (!sqlQuery) return null;

  return (
    <Paper
      elevation={0}
      sx={{
        p: 2.5,
        mb: 2.5,
        borderRadius: 3,
        border: '1px solid rgba(255,255,255,0.08)',
        borderLeft: '4px solid',
        borderLeftColor: 'primary.main',
      }}
    >
      <Typography
        variant="overline"
        color="text.secondary"
        sx={{ fontWeight: 700, letterSpacing: '0.1em' }}
      >
        Generated SQL
      </Typography>
      <Box
        component="pre"
        sx={{
          mt: 1.5,
          mb: 0,
          p: 2,
          borderRadius: 2,
          bgcolor: '#2C2C2C',
          overflowX: 'auto',
          fontFamily: 'ui-monospace, Menlo, Monaco, monospace',
          fontSize: '0.875rem',
          lineHeight: 1.6,
        }}
      >
        <code>{sqlQuery}</code>
      </Box>
    </Paper>
  );
};

export default SqlViewer;
