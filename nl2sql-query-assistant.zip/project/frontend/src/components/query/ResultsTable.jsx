import React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';

const ResultsTable = ({ results }) => {
  if (!results || results.length === 0) return null;

  const exportToCSV = () => {
    const headers = Object.keys(results[0]).join(',');
    const rows = results.map(row =>
      Object.values(row)
        .map(val => (val !== null ? `"${val.toString().replace(/"/g, '""')}"` : 'NULL'))
        .join(',')
    );
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'query_results.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Paper elevation={0} sx={{ p: 2.5, borderRadius: 3, border: '1px solid rgba(255,255,255,0.08)' }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="subtitle1" fontWeight={700}>
          Results ({results.length} rows)
        </Typography>
        <Button
          variant="outlined"
          color="primary"
          size="small"
          startIcon={<DownloadRoundedIcon />}
          onClick={exportToCSV}
        >
          Download CSV
        </Button>
      </Stack>

      <TableContainer sx={{ maxWidth: '100%' }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              {Object.keys(results[0]).map((key) => (
                <TableCell key={key}>{key}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {results.map((row, idx) => (
              <TableRow key={idx}>
                {Object.values(row).map((val, i) => (
                  <TableCell key={i}>
                    {val !== null ? val.toString() : (
                      <Typography component="span" color="text.secondary" variant="body2">NULL</Typography>
                    )}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default ResultsTable;
