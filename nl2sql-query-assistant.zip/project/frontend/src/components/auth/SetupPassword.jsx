import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import LockResetRoundedIcon from '@mui/icons-material/LockResetRounded';

const AuthShell = ({ children }) => (
  <Box
    sx={{
      minHeight: '100svh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      px: 2,
      background: (t) =>
        `radial-gradient(circle at 15% 20%, ${t.palette.background.paper} 0%, ${t.palette.background.default} 55%)`,
    }}
  >
    <Paper
      elevation={0}
      sx={{
        width: '100%',
        maxWidth: 420,
        p: { xs: 3, sm: 5 },
        borderRadius: 3,
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow: '0 20px 60px rgba(0,0,0,0.45)',
        textAlign: 'center',
      }}
    >
      {children}
    </Paper>
  </Box>
);

const SetupPassword = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (newPassword !== confirmPassword) {
      return setError('Passwords do not match.');
    }

    try {
      const res = await fetch('http://localhost:8000/auth/setup-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, new_password: newPassword })
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.detail || 'Failed to set password.');

      setIsSuccess(true);
      setMessage('Password successfully created! Redirecting to login...');

      // Automatically route back to login after success animation/message
      setTimeout(() => navigate('/login'), 3000);
    } catch (err) {
      setError(err.message);
    }
  };

  if (!token) {
    return (
      <AuthShell>
        <Typography variant="h5" fontWeight={700} gutterBottom>Invalid Link</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          No setup token provided. Please request a new verification link from the login page.
        </Typography>
        <Button variant="contained" onClick={() => navigate('/login')}>Back to Login</Button>
      </AuthShell>
    );
  }

  return (
    <AuthShell>
      <Stack alignItems="center" spacing={1.5} sx={{ mb: 3 }}>
        <Box
          sx={{
            width: 52,
            height: 52,
            borderRadius: 2,
            display: 'grid',
            placeItems: 'center',
            bgcolor: 'rgba(255,107,1,0.14)',
            border: '1px solid rgba(255,107,1,0.35)',
          }}
        >
          <LockResetRoundedIcon sx={{ color: 'primary.main' }} />
        </Box>
        <Typography variant="h5" fontWeight={700}>Create Password</Typography>
        <Typography variant="body2" color="text.secondary">
          Set up your permanent credentials to access the workspace.
        </Typography>
      </Stack>

      <Box component="form" onSubmit={handleSubmit} textAlign="left">
        <Stack spacing={2}>
          <TextField
            label="New Password"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            disabled={isSuccess}
            required
            fullWidth
          />
          <TextField
            label="Confirm Password"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            disabled={isSuccess}
            required
            fullWidth
          />

          {error && <Alert severity="error" variant="outlined">{error}</Alert>}
          {message && <Alert severity="success" variant="outlined">{message}</Alert>}

          <Button type="submit" variant="contained" size="large" fullWidth disabled={isSuccess} sx={{ py: 1.3 }}>
            Save Password
          </Button>
        </Stack>
      </Box>
    </AuthShell>
  );
};

export default SetupPassword;
