import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ isAllowed, redirectPath = '/', children }) => {
  if (!isAllowed) {
    // If the permission check fails, bounce them to the redirect path
    return <Navigate to={redirectPath} replace />;
  }

  // If they are allowed, render the requested child components
  return children ? children : null;
};

export default ProtectedRoute;