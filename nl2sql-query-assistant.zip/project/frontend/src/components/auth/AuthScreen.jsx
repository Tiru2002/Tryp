import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import Divider from '@mui/material/Divider';
import StorageRoundedIcon from '@mui/icons-material/StorageRounded';

const AuthScreen = ({ setToken, setIsAdmin, setUserProfile }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      if (isLoginMode) {
        // --- LOGIN FLOW ---
        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('password', password);

        const res = await fetch('http://localhost:8000/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: formData
        });

        if (!res.ok) throw new Error('Invalid credentials. Check your ID and password.');

        const data = await res.json();

        // Fail loudly instead of silently falling back to an empty object —
        // a corrupted or incomplete payload should surface as an error, not
        // render a blank/broken profile card downstream.
        if (!data.profile) throw new Error("Missing profile data");

        setToken(data.access_token);
        setIsAdmin(data.is_admin);
        setUserProfile(data.profile);

        // Persist session
        localStorage.setItem('token', data.access_token);
        localStorage.setItem('isAdmin', data.is_admin);
        localStorage.setItem('userProfile', JSON.stringify(data.profile));
      } else {
        // --- REQUEST SETUP LINK FLOW ---
        const res = await fetch('http://localhost:8000/auth/request-setup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username }) // They request a link using their Employee ID
        });

        if (!res.ok) throw new Error('Failed to request setup link.');

        const data = await res.json();
        setMessage(data.message);
        setUsername(''); // Clear the form on success
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100svh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        px: 2,
        background: (t) =>
          `radial-gradient(circle at 15% 20%, ${t.palette.background.paper} 0%, ${t.palette.background.default} 55%)`,
      }}
    >
      <Paper
        elevation={0}
        sx={{
          width: '100%',
          maxWidth: 420,
          p: { xs: 3, sm: 5 },
          borderRadius: 3,
          border: '1px solid rgba(255,255,255,0.08)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.45)',
        }}
      >
        <Stack alignItems="center" spacing={1.5} sx={{ mb: 3 }}>
          <Box
            sx={{
              width: 52,
              height: 52,
              borderRadius: 2,
              display: 'grid',
              placeItems: 'center',
              bgcolor: 'rgba(255,107,1,0.14)',
              border: '1px solid rgba(255,107,1,0.35)',
            }}
          >
            <StorageRoundedIcon sx={{ color: 'primary.main' }} />
          </Box>
          <Typography variant="h5" fontWeight={700} textAlign="center">
            {isLoginMode ? 'System Login' : 'Claim Your Account'}
          </Typography>
          <Typography variant="body2" color="text.secondary" textAlign="center">
            {isLoginMode
              ? 'Enter your Employee ID and password.'
              : 'Enter your Employee ID. We will email you a secure setup link.'}
          </Typography>
        </Stack>

        <Box component="form" onSubmit={handleAuth}>
          <Stack spacing={2}>
            <TextField
              label="Employee ID"
              placeholder="e.g., 4838"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              fullWidth
              autoFocus
            />
            {isLoginMode && (
              <TextField
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                fullWidth
              />
            )}

            {error && <Alert severity="error" variant="outlined">{error}</Alert>}
            {message && <Alert severity="success" variant="outlined">{message}</Alert>}

            <Button
              type="submit"
              variant="contained"
              color="primary"
              size="large"
              fullWidth
              disabled={loading}
              sx={{ py: 1.3, fontSize: '1rem' }}
            >
              {loading ? 'Please wait…' : isLoginMode ? 'Login' : 'Send Setup Link'}
            </Button>
          </Stack>
        </Box>

        <Divider sx={{ my: 3, borderColor: 'rgba(255,255,255,0.08)' }} />

        <Button
          fullWidth
          onClick={() => {
            setIsLoginMode(!isLoginMode);
            setError('');
            setMessage('');
            setPassword('');
          }}
          sx={{ color: 'text.secondary', '&:hover': { color: 'primary.main' } }}
        >
          {isLoginMode
            ? 'First time here? Set up your password'
            : 'Back to Login'}
        </Button>
      </Paper>
    </Box>
  );
};

export default AuthScreen;
