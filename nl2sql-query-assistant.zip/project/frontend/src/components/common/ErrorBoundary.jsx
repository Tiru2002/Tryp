import React from 'react';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import ErrorOutlineRoundedIcon from '@mui/icons-material/ErrorOutlineRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

/**
 * Generic React error boundary. Wrap any subtree that renders data-driven UI
 * (tables, charts, anything shaped by an API response) so a single bad
 * render doesn't take down the entire page — the rest of the dashboard
 * keeps working and the user gets a clear, recoverable fallback instead of
 * a blank screen.
 *
 * Usage:
 *   <ErrorBoundary label="results table">
 *     <ResultsTable results={results} />
 *   </ErrorBoundary>
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Centralized place to hook up real error reporting later
    // (Sentry, LogRocket, a /client-errors endpoint, etc.)
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      const { label } = this.props;
      return (
        <Paper
          elevation={0}
          sx={{
            p: 3,
            mb: 2.5,
            borderRadius: 3,
            border: '1px solid rgba(255,255,255,0.08)',
            bgcolor: 'rgba(255,255,255,0.02)',
          }}
        >
          <Stack spacing={1.25} alignItems="center" textAlign="center" sx={{ py: 2 }}>
            <ErrorOutlineRoundedIcon sx={{ fontSize: 32, color: 'primary.main' }} />
            <Typography variant="subtitle1" fontWeight={700}>
              {label ? `Couldn't render ${label}` : "Something went wrong rendering this section"}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 420 }}>
              The rest of the dashboard is unaffected. You can try again, or re-run your query.
            </Typography>
            <Button
              size="small"
              variant="outlined"
              color="primary"
              startIcon={<RefreshRoundedIcon />}
              onClick={this.handleReset}
              sx={{ mt: 0.5 }}
            >
              Try again
            </Button>
          </Stack>
        </Paper>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
