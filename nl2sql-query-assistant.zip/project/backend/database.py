from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime, ForeignKey, Text, func, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime

# Use SQLite for the PoC phase
SQLALCHEMY_DATABASE_URL = "sqlite:///./nl2sql.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True) # Used for Employee ID (e.g., "4838")
    email = Column(String(200), unique=True, index=True)    # Used for sending the setup link
    hashed_password = Column(String, nullable=True)
    is_admin = Column(Boolean, default=False)
    allowed_tables = Column(Text, default="employees,departments,projects")
    region = Column(String(100), default="")
    department_title = Column(String(100), default="")
    organization = Column(String(100), default="")

    # Email Setup Flow Fields
    setup_token = Column(String, unique=True, index=True, nullable=True)
    token_expiry = Column(DateTime, nullable=True)

    # Relationships
    queries = relationship("QueryLog", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")

class QueryLog(Base):
    __tablename__ = "query_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    question = Column(String, index=True)
    generated_sql = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship back to user
    user = relationship("User", back_populates="queries")

class SystemSettings(Base):
    __tablename__ = "system_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    row_limit = Column(Integer, default=500)
    system_prompt = Column(String, default="You are an expert SQL data analyst. Convert the following natural language request into a valid SQL query.")
    
    # NEW: Comma-separated list of tables the LLM is allowed to query
    allowed_tables = Column(String, default="employees,departments")

class AccessRequest(Base):
    __tablename__ = "access_requests"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    request_type = Column(String(100))  # e.g., "Table Access", "Higher Limits"
    requested_table = Column(String(100), nullable=False)
    description = Column(Text)
    status = Column(String(50), default="Pending") # "Pending", "Approved", "Denied"
    resolved_by = Column(String(50), nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship back to the user
    user = relationship("User")

class Department(Base):
    __tablename__ = "departments"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    dept_id = Column(Integer, ForeignKey("departments.id"))

class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    dept_id = Column(Integer, ForeignKey("departments.id"))
    project_id = Column(Integer, ForeignKey("projects.id"))

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    message = Column(Text)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, server_default=func.now())

    user = relationship("User", back_populates="notifications")


class BlacklistedToken(Base):
    """
    Stores JWTs that have been explicitly invalidated (e.g. via /logout).
    get_current_user() checks this table on every request so a signed-out
    token can no longer be used, even though JWTs are otherwise stateless.
    """
    __tablename__ = "blacklisted_tokens"

    id = Column(Integer, primary_key=True, index=True)
    token = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    blacklisted_at = Column(DateTime, default=datetime.utcnow)


def _sqlite_has_column(engine, table_name: str, column_name: str) -> bool:
    with engine.connect() as conn:
        result = conn.execute(text(f"PRAGMA table_info({table_name})"))
        return any(row[1] == column_name for row in result.fetchall())


def _sqlite_add_column(engine, table_name: str, column_definition: str) -> None:
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_definition}"))


def apply_sqlite_schema_updates(engine):
    if engine.dialect.name != 'sqlite':
        return

    table_columns = {
        'users': [
            ("allowed_tables", "TEXT DEFAULT 'employees,departments,projects'"),
            ("region", "VARCHAR(100) DEFAULT ''"),
            ("department_title", "VARCHAR(100) DEFAULT ''"),
            ("organization", "VARCHAR(100) DEFAULT ''"),
        ],
        'access_requests': [
            ("requested_table", "VARCHAR(100) DEFAULT ''"),
            ("resolved_by", "VARCHAR(50) DEFAULT ''"),
            ("resolved_at", "DATETIME"),
            ("rejection_reason", "TEXT DEFAULT ''"),
        ],
    }

    with engine.begin() as conn:
        for table_name, columns in table_columns.items():
            if not conn.execute(text(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")).fetchone():
                continue
            for column_name, column_def in columns:
                if not _sqlite_has_column(engine, table_name, column_name):
                    _sqlite_add_column(engine, table_name, f"{column_name} {column_def}")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()