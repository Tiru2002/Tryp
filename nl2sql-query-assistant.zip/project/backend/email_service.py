import logging
import os
import secrets
import smtplib
from email.message import EmailMessage

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("email_service")

# Loaded from .env — see .env.example for the required keys.
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SENDER_EMAIL = os.getenv("SMTP_EMAIL")
SENDER_PASSWORD = os.getenv("SMTP_PASSWORD")
FRONTEND_BASE_URL = os.getenv("FRONTEND_BASE_URL", "http://localhost:5173")


def generate_secure_token() -> str:
    """Generates a random URL-safe 32-character token."""
    return secrets.token_urlsafe(32)


def send_setup_email(recipient_email: str, token: str):
    """Sends the setup link via SMTP."""

    if not SENDER_EMAIL or not SENDER_PASSWORD:
        logger.error(
            "SMTP credentials are not configured. Set SMTP_EMAIL and SMTP_PASSWORD in .env. "
            "Setup email to %s was NOT sent.", recipient_email
        )
        return

    setup_link = f"{FRONTEND_BASE_URL}/setup-password?token={token}"

    msg = EmailMessage()
    msg['Subject'] = 'Action Required: Set up your Query Assistant Account'
    msg['From'] = SENDER_EMAIL
    msg['To'] = recipient_email

    msg.set_content(f"""
    Welcome to the Enterprise NL-to-SQL Query Assistant.

    An administrator has granted you access to the workspace.
    Please click the link below to set up your password and claim your account:

    {setup_link}

    This link will expire in 24 hours.
    If you did not request this, please contact IT support.
    """)

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.send_message(msg)
            logger.info("Setup email successfully sent to %s", recipient_email)
    except Exception as e:
        logger.error("Failed to send setup email to %s: %s", recipient_email, e, exc_info=True)
