import logging
import os
import re
from datetime import datetime, timedelta
from typing import List

import jwt
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, Request, status, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from sqlalchemy.orm import Session
from sqlalchemy import text

# Import local modules
from database import (
    AccessRequest, BlacklistedToken, Department, Project, Notification, engine,
    Base, get_db, User, QueryLog, SystemSettings, SessionLocal,
)
from email_service import send_setup_email, generate_secure_token

# Import your powerful LLM functions
from llm import generate_sql, generate_corrected_sql, generate_data_summary

load_dotenv()

# --- STRUCTURED LOGGING ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("nl2sql.api")

# Initialize Database Tables
Base.metadata.create_all(bind=engine)
from database import apply_sqlite_schema_updates
apply_sqlite_schema_updates(engine)

# --- RATE LIMITING ---
limiter = Limiter(key_func=get_remote_address)

app = FastAPI(title="Enterprise NL-to-SQL API")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- SECURITY & AUTHENTICATION SETTINGS ---
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("SECRET_KEY is not set. Add it to your .env file before starting the API.")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# Blocks any AI-generated SQL that tries to mutate or destroy data instead of
# reading it — the assistant should only ever run SELECTs.
DESTRUCTIVE_SQL_PATTERN = re.compile(r'\b(DROP|DELETE|UPDATE|INSERT|ALTER|TRUNCATE)\b', re.IGNORECASE)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    if not hashed_password:
        return False
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    # Server-side invalidation check: a token written to the blacklist by
    # /logout is rejected even if it hasn't expired yet.
    if db.query(BlacklistedToken).filter(BlacklistedToken.token == token).first():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked. Please log in again.",
        )

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    except jwt.PyJWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    
    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user

def get_current_admin(current_user: User = Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return current_user

# --- Notification Helper ---
def create_notification(db: Session, user_id: int, message: str):
    notification = Notification(user_id=user_id, message=message)
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification

# --- PYDANTIC MODELS ---
class SetupRequest(BaseModel): username: str
class NewUserRequest(BaseModel): username: str; email: str; is_admin: bool = False
class PasswordSetRequest(BaseModel): token: str; new_password: str
class QueryRequest(BaseModel): question: str
class SettingsRequest(BaseModel): row_limit: int; system_prompt: str; allowed_tables: List[str]
class AccessRequestCreate(BaseModel):
    request_type: str
    requested_table: str
    description: str

class AccessRequestUpdate(BaseModel):
    status: str
    rejection_reason: str = None

# --- AUTHENTICATION & SETUP ENDPOINTS ---

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    
    access_token = create_access_token(data={"sub": user.username})
    allowed_tables = [t for t in (user.allowed_tables or "").split(",") if t.strip()]
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "is_admin": user.is_admin,
        "profile": {
            "username": user.username,
            "email": user.email,
            "region": user.region,
            "department_title": user.department_title,
            "organization": user.organization,
            "allowed_tables_count": len(allowed_tables)
        }
    }

@app.post("/auth/request-setup")
def request_account_setup(req: SetupRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == req.username).first()
    if not user:
        return {"message": "If an account exists, a setup link has been sent."}

    token = generate_secure_token()
    user.setup_token = token
    user.token_expiry = datetime.utcnow() + timedelta(hours=24)
    db.commit()

    background_tasks.add_task(send_setup_email, user.email, token)
    return {"message": "If an account exists, a setup link has been sent."}

@app.post("/auth/setup-password")
def complete_password_setup(req: PasswordSetRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.setup_token == req.token).first()
    
    if not user or datetime.utcnow() > user.token_expiry:
        raise HTTPException(status_code=400, detail="Invalid or expired setup token.")
        
    user.hashed_password = get_password_hash(req.new_password)
    user.setup_token = None
    user.token_expiry = None
    db.commit()
    
    return {"message": "Password successfully set. You may now log in."}

@app.post("/logout")
def logout(
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Server-side JWT invalidation. Since JWTs are otherwise stateless and
    valid until they expire, we record the raw token in a blacklist table so
    get_current_user() can reject it on every subsequent request.
    """
    already_blacklisted = db.query(BlacklistedToken).filter(BlacklistedToken.token == token).first()
    if not already_blacklisted:
        db.add(BlacklistedToken(token=token, user_id=current_user.id))
        db.commit()

    logger.info("User logged out | user_id=%s | username=%s", current_user.id, current_user.username)
    return {"message": "Logged out successfully."}

# --- QUERY WORKSPACE ENDPOINTS ---

@app.get("/schema")
def get_db_schema(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    allowed_tables = [t for t in (current_user.allowed_tables or "").split(",") if t.strip()]

    # Mock full database schema representation for the React Sidebar
    full_schema = {
        "employees": [
            {"name": "id", "type": "INTEGER"},
            {"name": "name", "type": "VARCHAR"},
            {"name": "dept_id", "type": "INTEGER"},
            {"name": "project", "type": "INTEGER"}
        ],
        "departments": [
            {"name": "id", "type": "INTEGER"},
            {"name": "name", "type": "VARCHAR"}
        ],
        "projects": [
            {"name": "id", "type": "INTEGER"},
            {"name": "title", "type": "VARCHAR"},
            {"name": "dept_id", "type": "INTEGER"}
        ],
        "performance_reviews": [
            {"name": "id", "type": "INTEGER"},
            {"name": "employee_id", "type": "INTEGER"},
            {"name": "rating", "type": "VARCHAR"},
            {"name": "comments", "type": "TEXT"}
        ]
    }

    filtered_schema = {k: v for k, v in full_schema.items() if k in allowed_tables}
    return filtered_schema

@app.post("/query")
@limiter.limit("5/minute")
def run_nl_query(
    request: Request,
    req: QueryRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    settings = db.query(SystemSettings).first()
    row_limit = settings.row_limit if settings else 500
    system_prompt = settings.system_prompt if settings and settings.system_prompt else None
    allowed_tables = [t for t in (current_user.allowed_tables or "").split(",") if t.strip()]

    # Empty-schema short circuit: don't let the LLM hallucinate a query
    # against tables the user was never granted access to.
    if not allowed_tables:
        logger.info("Blocked query | user_id=%s | reason=no_authorized_tables", current_user.id)
        raise HTTPException(status_code=403, detail="No authorized tables")

    # Grab the user's last 3 queries for conversation context
    recent_logs = db.query(QueryLog).filter(QueryLog.user_id == current_user.id).order_by(QueryLog.created_at.desc()).limit(3).all()
    chat_history = list(reversed(recent_logs)) 

    try:
        # 1. Ask the LLM to write the SQL
        generated_sql = generate_sql(req.question, chat_history, row_limit, allowed_tables, system_prompt)

        # 1b. SQL Injection / destructive-command interceptor. The assistant
        # should only ever emit read-only SELECTs — block anything else
        # before it ever reaches db.execute().
        if DESTRUCTIVE_SQL_PATTERN.search(generated_sql):
            logger.error(
                "Blocked destructive SQL | user_id=%s | sql=%r", current_user.id, generated_sql
            )
            raise HTTPException(status_code=400, detail="Destructive commands blocked")

        # 2. Execute the SQL against the database
        try:
            result_proxy = db.execute(text(generated_sql))
            if result_proxy.returns_rows:
                actual_results = [dict(row._mapping) for row in result_proxy]
            else:
                actual_results = []
                db.commit() 
        except HTTPException:
            raise
        except Exception as db_e:
            # 3. If SQL fails, trigger the Self-Correction Loop!
            logger.warning(
                "Initial SQL failed, attempting AI correction | user_id=%s | error=%s",
                current_user.id, db_e,
            )
            generated_sql = generate_corrected_sql(
                req.question, generated_sql, str(db_e), chat_history, row_limit, allowed_tables, system_prompt
            )

            # Re-check the corrected SQL before executing it too.
            if DESTRUCTIVE_SQL_PATTERN.search(generated_sql):
                logger.error(
                    "Blocked destructive SQL (post-correction) | user_id=%s | sql=%r",
                    current_user.id, generated_sql,
                )
                raise HTTPException(status_code=400, detail="Destructive commands blocked")

            # Try running the corrected SQL
            result_proxy = db.execute(text(generated_sql))
            if result_proxy.returns_rows:
                actual_results = [dict(row._mapping) for row in result_proxy]
            else:
                actual_results = []

        # 4. Generate the Insight Summary
        summary = generate_data_summary(req.question, actual_results)

    except HTTPException:
        raise
    except Exception as e:
        logger.error("System error while running query | user_id=%s | error=%s", current_user.id, e, exc_info=True)
        generated_sql = "-- Error generating or executing query"
        actual_results = []
        summary = f"An error occurred: {str(e)}"

    # Log the successful interaction
    new_log = QueryLog(user_id=current_user.id, question=req.question, generated_sql=generated_sql)
    db.add(new_log)
    db.commit()

    return {
        "sql": generated_sql,
        "results": actual_results,
        "summary": summary
    }

@app.get("/history")
def get_user_history(limit: int = 10, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    logs = db.query(QueryLog).filter(QueryLog.user_id == current_user.id).order_by(QueryLog.created_at.desc()).limit(limit).all()
    return logs

@app.get("/profile")
def get_user_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    allowed_tables = [t for t in (current_user.allowed_tables or "").split(",") if t.strip()]
    query_count = db.query(QueryLog).filter(QueryLog.user_id == current_user.id).count()
    pending_approvals = db.query(AccessRequest).filter(
        AccessRequest.user_id == current_user.id,
        AccessRequest.status == "Pending"
    ).count()
    return {
        "profile": {
            "username": current_user.username,
            "email": current_user.email,
            "region": current_user.region,
            "department_title": current_user.department_title,
            "organization": current_user.organization,
            "allowed_tables_count": len(allowed_tables),
            "allowed_tables": allowed_tables,
        },
        "metrics": {
            "queries_executed": query_count,
            "pending_approvals": pending_approvals,
        }
    }

@app.get("/requests")
def get_user_requests(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    requests = db.query(AccessRequest).filter(AccessRequest.user_id == current_user.id).order_by(AccessRequest.created_at.desc()).all()
    return [
        {
            "id": r.id,
            "request_type": r.request_type,
            "requested_table": r.requested_table,
            "description": r.description,
            "status": r.status,
            "resolved_by": r.resolved_by,
            "resolved_at": r.resolved_at,
            "rejection_reason": r.rejection_reason,
            "created_at": r.created_at
        }
        for r in requests
    ]

# --- ADMIN DASHBOARD ENDPOINTS ---

@app.get("/admin/users")
def get_all_users(current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    users = db.query(User).all()
    result = []
    for u in users:
        status = "Active" if u.hashed_password else "Pending Setup"
        result.append({
            "id": u.id,
            "username": u.username,
            "is_admin": u.is_admin,
            "status": status
        })
    return result

@app.post("/admin/users")
def provision_user(
    req: NewUserRequest, 
    background_tasks: BackgroundTasks, 
    current_admin: User = Depends(get_current_admin), 
    db: Session = Depends(get_db)
):
    if db.query(User).filter(User.username == req.username).first():
        raise HTTPException(status_code=400, detail="Employee ID already exists.")
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(status_code=400, detail="Email already registered.")
        
    # Generate the secure token
    token = generate_secure_token()
    expiry_time = datetime.utcnow() + timedelta(hours=24)
        
    # Add the token fields directly to the new user object
    new_user = User(
        username=req.username, 
        email=req.email,
        is_admin=req.is_admin, 
        hashed_password=None,
        setup_token=token,          
        token_expiry=expiry_time     
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Pass the generated token into the background email task
    background_tasks.add_task(send_setup_email, new_user.email, token)
    
    return {"message": f"Successfully authorized {req.username}."}

@app.delete("/admin/users/{user_id}")
def revoke_access(user_id: int, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    db.delete(user)
    db.commit()
    return {"message": "Access revoked."}

@app.get("/admin/logs")
def get_global_logs(
    skip: int = 0,
    limit: int = 50,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    base_query = db.query(QueryLog).order_by(QueryLog.created_at.desc())
    total = base_query.count()
    logs = base_query.offset(skip).limit(limit).all()

    result = []
    for log in logs:
        result.append({
            "id": log.id,
            "username": log.user.username,
            "question": log.question,
            "generated_sql": log.generated_sql,
            "created_at": log.created_at
        })
    return {"total": total, "skip": skip, "limit": limit, "items": result}

@app.get("/admin/settings")
def get_settings(current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    settings = db.query(SystemSettings).first()
    if not settings:
        settings = SystemSettings(
            row_limit=500, 
            system_prompt="You are an expert SQL data analyst. Convert the following natural language request into a valid SQL query.",
            allowed_tables="employees,departments,projects"
        )
        db.add(settings)
        db.commit()
        db.refresh(settings)
    
    return {
        "row_limit": settings.row_limit, 
        "system_prompt": settings.system_prompt,
        "allowed_tables": settings.allowed_tables.split(",") if settings.allowed_tables else []
    }

@app.post("/admin/settings")
def update_settings(req: SettingsRequest, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    settings = db.query(SystemSettings).first()
    table_string = ",".join(req.allowed_tables)
    
    if not settings:
        settings = SystemSettings(
            row_limit=req.row_limit, 
            system_prompt=req.system_prompt,
            allowed_tables=table_string
        )
        db.add(settings)
    else:
        settings.row_limit = req.row_limit
        settings.system_prompt = req.system_prompt
        settings.allowed_tables = table_string
        
    db.commit()
    return {"message": "Settings updated"}

@app.get("/notifications")
def get_notifications(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    notifications = db.query(Notification).filter(Notification.user_id == current_user.id, Notification.is_read == False).order_by(Notification.created_at.desc()).all()
    return [
        {
            "id": n.id,
            "message": n.message,
            "created_at": n.created_at,
            "is_read": n.is_read
        }
        for n in notifications
    ]

@app.put("/notifications/{notification_id}/read")
def mark_notification_read(notification_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    notification = db.query(Notification).filter(Notification.id == notification_id, Notification.user_id == current_user.id).first()
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    notification.is_read = True
    db.commit()
    return {"message": "Notification marked as read."}

@app.get("/admin/tables")
def get_all_physical_tables(current_admin: User = Depends(get_current_admin)):
    return ["employees", "departments", "projects", "salaries", "performance_reviews", "system_settings", "users", "query_logs"]

# --- REQUEST MANAGEMENT ENDPOINTS ---

@app.post("/requests")
def submit_access_request(req: AccessRequestCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    new_request = AccessRequest(
        user_id=current_user.id,
        request_type=req.request_type,
        requested_table=req.requested_table,
        description=req.description,
        status="Pending"
    )
    db.add(new_request)
    db.commit()
    db.refresh(new_request)

    admin_message = f"New table access request submitted by {current_user.username}."
    admin_users = db.query(User).filter(User.is_admin == True).all()
    for admin in admin_users:
        create_notification(db, admin.id, admin_message)

    return {
        "message": "Request submitted successfully. Pending admin review.",
        "request": {
            "id": new_request.id,
            "status": new_request.status,
            "requested_table": new_request.requested_table,
            "description": new_request.description,
            "created_at": new_request.created_at.isoformat()
        }
    }

@app.get("/admin/requests")
def get_all_requests(
    skip: int = 0,
    limit: int = 50,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    base_query = db.query(AccessRequest).order_by(AccessRequest.created_at.desc())
    total = base_query.count()
    requests = base_query.offset(skip).limit(limit).all()

    items = [{
        "id": r.id,
        "username": r.user.username,
        "request_type": r.request_type,
        "requested_table": r.requested_table,
        "description": r.description,
        "status": r.status,
        "resolved_by": r.resolved_by,
        "resolved_at": r.resolved_at,
        "rejection_reason": r.rejection_reason,
        "created_at": r.created_at
    } for r in requests]

    return {"total": total, "skip": skip, "limit": limit, "items": items}

@app.put("/admin/requests/{request_id}")
def update_request_status(request_id: int, req: AccessRequestUpdate, current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    db_request = db.query(AccessRequest).filter(AccessRequest.id == request_id).first()
    if not db_request:
        raise HTTPException(status_code=404, detail="Request not found")

    db_request.status = req.status
    db_request.resolved_by = current_admin.username
    db_request.resolved_at = datetime.utcnow()
    if req.status == "Denied":
        db_request.rejection_reason = req.rejection_reason or "No reason provided."

    if req.status == "Approved":
        requesting_user = db.query(User).filter(User.id == db_request.user_id).first()
        if requesting_user:
            existing_tables = [t.strip() for t in (requesting_user.allowed_tables or "").split(",") if t.strip()]
            if db_request.requested_table not in existing_tables:
                existing_tables.append(db_request.requested_table)
                requesting_user.allowed_tables = ",".join(existing_tables)

    db.commit()

    requesting_user = db.query(User).filter(User.id == db_request.user_id).first()
    if requesting_user:
        result_text = "Approved" if req.status == "Approved" else "Denied"
        user_message = (
            f"Your access request for {db_request.requested_table} has been {result_text} by {current_admin.username}."
        )
        if req.status == "Denied":
            user_message += f" Reason: {db_request.rejection_reason}"
        create_notification(db, requesting_user.id, user_message)

    return {
        "message": f"Request {req.status.lower()}.",
        "request": {
            "id": db_request.id,
            "status": db_request.status,
            "resolved_by": db_request.resolved_by,
            "resolved_at": db_request.resolved_at.isoformat() if db_request.resolved_at else None,
            "requested_table": db_request.requested_table,
            "rejection_reason": db_request.rejection_reason,
            "user_id": db_request.user_id
        }
    }

# --- DATA RETENTION POLICY ---

RETENTION_DAYS = int(os.getenv("LOG_RETENTION_DAYS", "90"))

def purge_expired_records(db: Session) -> dict:
    """
    Deletes query_logs and notifications older than RETENTION_DAYS.
    Called on a schedule (e.g. cron hitting the admin endpoint below) or
    directly from a maintenance script.
    """
    cutoff = datetime.utcnow() - timedelta(days=RETENTION_DAYS)

    deleted_logs = db.query(QueryLog).filter(QueryLog.created_at < cutoff).delete(synchronize_session=False)
    deleted_notifications = db.query(Notification).filter(Notification.created_at < cutoff).delete(synchronize_session=False)
    db.commit()

    logger.info(
        "Retention purge complete | cutoff=%s | deleted_logs=%s | deleted_notifications=%s",
        cutoff.isoformat(), deleted_logs, deleted_notifications,
    )
    return {
        "cutoff": cutoff.isoformat(),
        "deleted_query_logs": deleted_logs,
        "deleted_notifications": deleted_notifications,
    }


@app.post("/admin/retention/purge")
def run_retention_purge(current_admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """
    Manually (or via a scheduled job / cron hitting this endpoint) deletes
    query_logs and notifications older than the configured retention window
    (default 90 days, see LOG_RETENTION_DAYS in .env).
    """
    result = purge_expired_records(db)
    logger.info("Retention purge triggered by admin_id=%s", current_admin.id)
    return {"message": "Retention purge complete.", **result}


# --- STARTUP LOGIC ---

def seed_test_data(db: Session):
    if not db.query(Department).first():
        engineering = Department(name="Engineering")
        sales = Department(name="Sales")
        db.add_all([engineering, sales])
        db.commit() 
        
        projects = [
            Project(title="AI Model Training", dept_id=engineering.id),
            Project(title="Database Optimization", dept_id=engineering.id),
            Project(title="Lead Generation", dept_id=sales.id)
        ]
        db.add_all(projects)
        db.commit()
        logger.info("Test data seeded successfully.")

@app.on_event("startup")
def startup_event():
    db = SessionLocal()
    try:
        if not db.query(User).filter(User.username == "admin").first():
            admin = User(
                username="admin",
                hashed_password=get_password_hash("admin"),
                is_admin=True
            )
            db.add(admin)
            db.commit()
            logger.info("Default admin account created.")
        seed_test_data(db)
    finally:
        db.close()